import type { Metadata } from 'next'
import Image from 'next/image'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { EvidenceGrid } from '@/components/archive/evidence-grid'
import { CASE_ID, evidence } from '@/lib/case-data'

export const metadata: Metadata = {
  title: 'Evidence Archive — The Last Signal',
  description: 'Catalogued photographs, physical evidence, locations and documents for the case file.',
}

export default function ArchivePage() {
  const available = evidence.filter((e) => e.status === 'available').length

  return (
    <>
      <SiteHeader current="archive" />
      <main>
        <section className="relative isolate overflow-hidden border-b border-border">
          <Image
            src="/images/ev-archive-room.png"
            alt=""
            fill
            sizes="100vw"
            className="-z-20 object-cover opacity-35 saturate-50"
          />
          <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-r from-background via-background/85 to-background/40" />
          <div aria-hidden className="film-grain absolute inset-0 -z-10" />
          <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 md:grid-cols-[1fr_auto] md:items-end md:px-10 md:py-28">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-crimson">Section 02 — {CASE_ID}</p>
              <h1 className="mt-4 font-serif text-5xl font-light leading-none md:text-7xl">Evidence archive</h1>
              <p className="mt-6 max-w-xl leading-relaxed text-foreground/75">
                Every item logged against the case. Restricted items are released as the investigation
                progresses; sealed items remain withheld.
              </p>
            </div>
            <dl className="grid grid-cols-3 gap-8 font-mono text-[11px] uppercase tracking-[0.2em]">
              <div>
                <dt className="text-muted-foreground">Logged</dt>
                <dd className="mt-2 font-serif text-4xl font-light normal-case tracking-normal">{String(evidence.length).padStart(2, '0')}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Open</dt>
                <dd className="mt-2 font-serif text-4xl font-light normal-case tracking-normal">{String(available).padStart(2, '0')}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Withheld</dt>
                <dd className="mt-2 font-serif text-4xl font-light normal-case tracking-normal text-[#d38a8a]">
                  {String(evidence.length - available).padStart(2, '0')}
                </dd>
              </div>
            </dl>
          </div>
        </section>

        <section aria-label="Evidence items" className="mx-auto max-w-7xl px-5 py-14 md:px-10 md:py-20">
          <EvidenceGrid items={evidence} />
        </section>
      </main>
      <SiteFooter />
    </>
  )
}
