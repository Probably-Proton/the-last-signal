import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Lock } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { DocumentViewer } from '@/components/viewer/document-viewer'
import { evidence, getEvidence } from '@/lib/case-data'

export function generateStaticParams() {
  return evidence.map((item) => ({ id: item.id }))
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params
  const item = getEvidence(id)
  if (!item) return { title: 'Not found — The Last Signal' }
  return {
    title: `${item.id} ${item.status === 'available' ? item.title : 'Restricted'} — The Last Signal`,
    description: item.status === 'available' ? item.description : 'This item is currently restricted.',
  }
}

export default async function ViewerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const item = getEvidence(id)
  if (!item) notFound()

  if (item.status !== 'available') {
    return (
      <>
        <SiteHeader current="viewer" />
        <main className="mx-auto flex min-h-[70svh] max-w-xl flex-col items-center justify-center px-5 text-center">
          <Lock aria-hidden className="size-6 text-crimson" />
          <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.28em] text-muted-foreground">{item.id}</p>
          <h1 className="mt-3 font-serif text-4xl font-light">Access restricted</h1>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            This item is released at stage {String(item.stage).padStart(2, '0')} of the investigation.
          </p>
          <Link
            href="/archive"
            className="mt-8 border border-border px-5 py-3 font-mono text-[11px] uppercase tracking-[0.22em] hover:border-foreground/60"
          >
            Return to archive
          </Link>
        </main>
      </>
    )
  }

  const open = evidence.filter((e) => e.status === 'available')
  const index = open.findIndex((e) => e.id === item.id)

  return (
    <>
      <SiteHeader current="viewer" />
      <main>
        <DocumentViewer item={item} prevId={open[index - 1]?.id} nextId={open[index + 1]?.id} />
      </main>
    </>
  )
}
