import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Hero } from '@/components/landing/hero'
import { StageIndex } from '@/components/landing/stage-index'

export default function Page() {
  return (
    <>
      <SiteHeader current="case" overlay />
      <main>
        <Hero />
        <StageIndex />
      </main>
      <SiteFooter />
    </>
  )
}
