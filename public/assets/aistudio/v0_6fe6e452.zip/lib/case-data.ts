export const CASE_ID = 'TLS-0017'

export type EvidenceKind = 'Scene photograph' | 'Physical evidence' | 'Location' | 'Document' | 'Audio'
export type EvidenceStatus = 'available' | 'restricted' | 'sealed'

export type EvidenceItem = {
  id: string
  title: string
  kind: EvidenceKind
  date: string
  classification: 'Confidential' | 'Restricted' | 'Internal'
  status: EvidenceStatus
  stage: number
  image?: string
  description: string
  hasDocument?: boolean
}

export const stages = [
  { number: 1, title: 'The archive', subtitle: "The archivist's letter" },
  { number: 2, title: 'The locked files', subtitle: 'Coordinates' },
  { number: 3, title: 'The witness', subtitle: 'Testimony and the map' },
  { number: 4, title: 'The reversed audio', subtitle: 'The suspicious call' },
  { number: 5, title: 'The newspaper', subtitle: 'Suspect database' },
  { number: 6, title: "Ellen Vale's journal", subtitle: 'The final review' },
  { number: 7, title: 'The final article', subtitle: 'The last signal' },
] as const

const PLACEHOLDER = 'Placeholder entry — case content has not been supplied yet.'

export const evidence: EvidenceItem[] = [
  {
    id: 'EV-0101',
    title: 'Scene overview, rear alley',
    kind: 'Scene photograph',
    date: '00 / 00 / 0000',
    classification: 'Confidential',
    status: 'available',
    stage: 1,
    image: '/images/hero-scene.png',
    description: `Wide establishing frame of the scene at night. ${PLACEHOLDER}`,
    hasDocument: true,
  },
  {
    id: 'EV-0102',
    title: 'Portable receiver',
    kind: 'Physical evidence',
    date: '00 / 00 / 0000',
    classification: 'Confidential',
    status: 'available',
    stage: 1,
    image: '/images/ev-radio.png',
    description: `Item photographed with scale marker. ${PLACEHOLDER}`,
    hasDocument: true,
  },
  {
    id: 'EV-0103',
    title: 'Sealed correspondence',
    kind: 'Document',
    date: '00 / 00 / 0000',
    classification: 'Restricted',
    status: 'available',
    stage: 1,
    image: '/images/ev-letter.png',
    description: `Letter retained in evidence bag. ${PLACEHOLDER}`,
    hasDocument: true,
  },
  {
    id: 'EV-0201',
    title: 'Records room, lower level',
    kind: 'Location',
    date: '00 / 00 / 0000',
    classification: 'Internal',
    status: 'available',
    stage: 2,
    image: '/images/ev-archive-room.png',
    description: `Location photograph. ${PLACEHOLDER}`,
  },
  {
    id: 'EV-0301',
    title: 'Transmission mast',
    kind: 'Location',
    date: '00 / 00 / 0000',
    classification: 'Internal',
    status: 'restricted',
    stage: 3,
    image: '/images/ev-tower.png',
    description: 'Access restricted until the stage is opened.',
  },
  {
    id: 'EV-0401',
    title: 'Recovered cassette',
    kind: 'Audio',
    date: '00 / 00 / 0000',
    classification: 'Restricted',
    status: 'restricted',
    stage: 4,
    image: '/images/ev-cassette.png',
    description: 'Access restricted until the stage is opened.',
  },
  {
    id: 'EV-0501',
    title: 'Newspaper bundle',
    kind: 'Document',
    date: '00 / 00 / 0000',
    classification: 'Restricted',
    status: 'sealed',
    stage: 5,
    image: '/images/ev-newspaper.png',
    description: 'Sealed. Contents withheld.',
  },
  {
    id: 'EV-0601',
    title: 'Withheld item',
    kind: 'Document',
    date: '00 / 00 / 0000',
    classification: 'Confidential',
    status: 'sealed',
    stage: 6,
    description: 'Sealed. Contents withheld.',
  },
]

export function getEvidence(id: string) {
  return evidence.find((item) => item.id === id)
}
