'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, ChevronLeft, ChevronRight, Minus, Plus, Maximize2 } from 'lucide-react'
import type { EvidenceItem } from '@/lib/case-data'
import { AttachmentPage, ContinuationPage, ReportPage } from './document-pages'

const ZOOM_STEPS = [0.75, 1, 1.25, 1.5, 2]
const PAGE_LABELS = ['Incident report', 'Photo attachment', 'Continuation']

export function DocumentViewer({ item, prevId, nextId }: { item: EvidenceItem; prevId?: string; nextId?: string }) {
  const [page, setPage] = useState(0)
  const [zoomIndex, setZoomIndex] = useState(1)
  const total = PAGE_LABELS.length
  const zoom = ZOOM_STEPS[zoomIndex]

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.target instanceof HTMLElement && e.target.closest('input, textarea')) return
      if (e.key === 'ArrowRight') setPage((p) => Math.min(total - 1, p + 1))
      if (e.key === 'ArrowLeft') setPage((p) => Math.max(0, p - 1))
      if (e.key === '+' || e.key === '=') setZoomIndex((z) => Math.min(ZOOM_STEPS.length - 1, z + 1))
      if (e.key === '-') setZoomIndex((z) => Math.max(0, z - 1))
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [total])

  const pages = [
    <ReportPage key="r" item={item} total={total} />,
    <AttachmentPage key="a" item={item} total={total} />,
    <ContinuationPage key="c" item={item} total={total} />,
  ]

  const toolButton =
    'inline-flex size-9 items-center justify-center border border-border text-foreground transition-colors hover:border-foreground/60 hover:bg-secondary disabled:pointer-events-none disabled:opacity-30'

  return (
    <div className="grid min-h-[calc(100svh-57px)] lg:grid-cols-[260px_minmax(0,1fr)_300px]">
      <aside aria-label="Pages" className="hidden border-r border-border lg:block">
        <div className="sticky top-[57px] p-5">
          <Link
            href="/archive"
            className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft aria-hidden className="size-3.5" /> Back to archive
          </Link>
          <p className="mt-8 font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">Contents</p>
          <ol className="mt-4 space-y-3">
            {PAGE_LABELS.map((label, i) => (
              <li key={label}>
                <button
                  type="button"
                  onClick={() => setPage(i)}
                  aria-current={page === i ? 'page' : undefined}
                  className={`group flex w-full items-center gap-3 text-left ${page === i ? '' : 'opacity-60 hover:opacity-100'}`}
                >
                  <span
                    aria-hidden
                    className={`paper-sheet block aspect-[8.5/11] w-12 shrink-0 ${page === i ? 'outline outline-2 outline-offset-2 outline-crimson' : ''}`}
                  />
                  <span>
                    <span className="block font-mono text-[10px] tracking-[0.18em] text-muted-foreground">
                      P. {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="block font-serif text-base text-foreground">{label}</span>
                  </span>
                </button>
              </li>
            ))}
          </ol>
        </div>
      </aside>

      <section aria-label="Document" className="flex min-w-0 flex-col bg-[#0a0a09]">
        <div
          role="toolbar"
          aria-label="Viewer controls"
          className="sticky top-[57px] z-20 flex items-center justify-between gap-3 border-b border-border bg-background/95 px-4 py-2.5 backdrop-blur"
        >
          <div className="flex items-center gap-2">
            <button type="button" className={toolButton} onClick={() => setPage((p) => p - 1)} disabled={page === 0} aria-label="Previous page">
              <ChevronLeft className="size-4" />
            </button>
            <p className="min-w-20 text-center font-mono text-[11px] tracking-[0.18em]" aria-live="polite">
              {page + 1} / {total}
            </p>
            <button type="button" className={toolButton} onClick={() => setPage((p) => p + 1)} disabled={page === total - 1} aria-label="Next page">
              <ChevronRight className="size-4" />
            </button>
          </div>
          <p className="hidden truncate font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground md:block">
            {item.id} · {PAGE_LABELS[page]}
          </p>
          <div className="flex items-center gap-2">
            <button type="button" className={toolButton} onClick={() => setZoomIndex((z) => z - 1)} disabled={zoomIndex === 0} aria-label="Zoom out">
              <Minus className="size-4" />
            </button>
            <p className="w-12 text-center font-mono text-[11px] tracking-[0.1em]">{Math.round(zoom * 100)}%</p>
            <button
              type="button"
              className={toolButton}
              onClick={() => setZoomIndex((z) => z + 1)}
              disabled={zoomIndex === ZOOM_STEPS.length - 1}
              aria-label="Zoom in"
            >
              <Plus className="size-4" />
            </button>
            <button type="button" className={toolButton} onClick={() => setZoomIndex(1)} aria-label="Reset zoom">
              <Maximize2 className="size-3.5" />
            </button>
          </div>
        </div>

        <div className="relative flex-1 overflow-auto">
          <div aria-hidden className="film-grain pointer-events-none fixed inset-0 z-10 opacity-10" />
          <div className="px-4 py-10 md:px-10 md:py-14">
            <div
              className="@container mx-auto"
              style={{ width: zoom <= 1 ? `min(100%, ${760 * zoom}px)` : `${760 * zoom}px` }}
            >
              <div style={{ fontSize: '2.1cqw' }}>{pages[page]}</div>
            </div>
          </div>
        </div>
      </section>

      <aside aria-label="Item record" className="border-t border-border lg:border-l lg:border-t-0">
        <div className="sticky top-[57px] space-y-8 p-6">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-crimson">Item record</p>
            <h1 className="mt-3 font-serif text-3xl font-light leading-tight">{item.title}</h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
          </div>
          <dl className="divide-y divide-border border-y border-border font-mono text-[11px] uppercase tracking-[0.16em]">
            {[
              ['Reference', item.id],
              ['Type', item.kind],
              ['Logged', item.date],
              ['Classification', item.classification],
              ['Stage', String(item.stage).padStart(2, '0')],
              ['Chain of custody', 'Intact'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-3">
                <dt className="text-muted-foreground">{k}</dt>
                <dd className="text-right text-foreground">{v}</dd>
              </div>
            ))}
          </dl>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">Investigator notes</p>
            <p className="mt-3 font-hand text-2xl leading-snug text-foreground/80">Notes will appear here once the story is written.</p>
          </div>
          <nav aria-label="Adjacent items" className="grid grid-cols-2 gap-3 font-mono text-[10px] uppercase tracking-[0.2em]">
            {prevId ? (
              <Link href={`/archive/${prevId}`} className="border border-border p-3 hover:border-foreground/60">
                <span className="text-muted-foreground">← Prev</span>
                <span className="mt-1 block text-foreground">{prevId}</span>
              </Link>
            ) : (
              <span />
            )}
            {nextId ? (
              <Link href={`/archive/${nextId}`} className="border border-border p-3 text-right hover:border-foreground/60">
                <span className="text-muted-foreground">Next →</span>
                <span className="mt-1 block text-foreground">{nextId}</span>
              </Link>
            ) : (
              <span />
            )}
          </nav>
          <p className="font-mono text-[10px] leading-relaxed tracking-[0.12em] text-muted-foreground">
            Keys: ← → to turn pages, + − to zoom.
          </p>
        </div>
      </aside>
    </div>
  )
}
