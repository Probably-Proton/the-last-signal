import Image from 'next/image'
import { CASE_ID, type EvidenceItem } from '@/lib/case-data'

function Sheet({ children, page, total }: { children: React.ReactNode; page: number; total: number }) {
  return (
    <div className="paper-sheet relative aspect-[8.5/11] w-full overflow-hidden px-[8%] py-[7%] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)]">
      {children}
      <div className="absolute inset-x-[8%] bottom-[3.5%] flex justify-between font-mono text-[0.6em] uppercase tracking-[0.2em] text-ink/60">
        <span>Form PD-114 / Rev. 00</span>
        <span>
          Page {page} of {total}
        </span>
      </div>
    </div>
  )
}

function Field({ label, value, redacted = false }: { label: string; value: string; redacted?: boolean }) {
  return (
    <div className="border-b border-ink/40 pb-1">
      <p className="font-mono text-[0.55em] uppercase tracking-[0.18em] text-ink/60">{label}</p>
      <p className="mt-0.5 font-mono text-[0.8em]">
        {redacted ? (
          <>
            <span className="redact">{value}</span>
            <span className="sr-only">Redacted</span>
          </>
        ) : (
          value
        )}
      </p>
    </div>
  )
}

function Letterhead({ title }: { title: string }) {
  return (
    <div className="flex items-start justify-between border-b-2 border-ink pb-[3%]">
      <div>
        <p className="font-mono text-[0.6em] uppercase tracking-[0.25em] text-ink/70">Department of Investigation — Records Division</p>
        <h2 className="mt-1 font-serif text-[1.7em] font-semibold leading-none tracking-tight">{title}</h2>
      </div>
      <div className="text-right font-mono text-[0.6em] uppercase tracking-[0.18em] text-ink/70">
        <p>Case no.</p>
        <p className="text-[1.4em] font-semibold tracking-[0.1em] text-ink">{CASE_ID}</p>
      </div>
    </div>
  )
}

export function ReportPage({ item, total }: { item: EvidenceItem; total: number }) {
  return (
    <Sheet page={1} total={total}>
      <Letterhead title="Incident Report" />

      <div className="mt-[4%] grid grid-cols-3 gap-x-[4%] gap-y-[3%]">
        <Field label="Date of report" value={item.date} />
        <Field label="Time" value="00:00" />
        <Field label="Item ref." value={item.id} />
        <Field label="Reporting officer" value="[Placeholder name]" />
        <Field label="Badge no." value="0000000" redacted />
        <Field label="Classification" value={item.classification} />
        <div className="col-span-3">
          <Field label="Location" value="[Location to be supplied by case writers]" />
        </div>
      </div>

      <p className="mt-[5%] font-mono text-[0.55em] uppercase tracking-[0.18em] text-ink/60">Narrative</p>
      <div className="mt-[1.5%] space-y-[0.9em] font-mono text-[0.72em] leading-[1.75]">
        <p>
          This report is a design placeholder. The narrative of the incident will be entered here once
          the official case text has been supplied. At approximately{' '}
          <span className="redact">00:00 hours</span> the reporting officer attended the location
          referenced above and logged item {item.id}.
        </p>
        <p>
          A summary of observations, persons present, and actions taken will appear in this section.
          Names of private individuals have been <span className="redact">withheld pending review</span>{' '}
          in accordance with records policy.
        </p>
        <p>
          Supporting photographs are attached on the following page. Further statements are recorded
          on continuation sheets.
        </p>
      </div>

      <p
        aria-label="Handwritten annotation"
        className="absolute left-[34%] top-[66%] rotate-[-4deg] font-hand text-[1.35em] leading-tight text-[#1e3a8a]"
      >
        verify against archive log
      </p>
      <svg aria-hidden className="absolute left-[24%] top-[60%] h-[6%] w-[10%] text-[#1e3a8a]" viewBox="0 0 100 50" fill="none">
        <path d="M95 45 C 70 40, 30 30, 10 6 M10 6 l 2 14 M10 6 l 13 4" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      </svg>

      <div className="absolute bottom-[10%] left-[8%] right-[8%] grid grid-cols-2 gap-[6%]">
        <div className="border-t border-ink/60 pt-1 font-mono text-[0.55em] uppercase tracking-[0.18em] text-ink/60">
          Signature of officer
        </div>
        <div className="border-t border-ink/60 pt-1 font-mono text-[0.55em] uppercase tracking-[0.18em] text-ink/60">
          Reviewed by
        </div>
      </div>
      <p className="absolute bottom-[12.5%] left-[10%] rotate-[-3deg] font-hand text-[1.5em] text-ink/80" aria-hidden>
        [signature]
      </p>

      <span className="stamp absolute right-[26%] top-[4.5%] rotate-[-6deg] text-[0.95em] font-semibold text-crimson">
        {item.classification}
      </span>
      <span className="stamp absolute bottom-[17%] right-[10%] rotate-[-11deg] text-[0.7em] text-[#3b4a6b]">
        Received
        <br />
        <span className="text-[0.85em] tracking-[0.15em]">00 · 00 · 0000</span>
      </span>
    </Sheet>
  )
}

export function AttachmentPage({ item, total }: { item: EvidenceItem; total: number }) {
  return (
    <Sheet page={2} total={total}>
      <Letterhead title="Photographic Attachment" />
      <p className="mt-[3%] font-mono text-[0.6em] uppercase tracking-[0.18em] text-ink/60">
        Exhibit {item.id}-A — {item.kind}
      </p>

      <figure className="relative mx-auto mt-[5%] w-[82%] rotate-[-1.5deg] bg-[#f6f2ea] p-[2.5%] pb-[8%] shadow-[0_8px_20px_rgba(0,0,0,0.35)]">
        <div className="relative aspect-[4/3] overflow-hidden bg-ink">
          {item.image && (
            <Image src={item.image} alt={`Attached photograph: ${item.title}`} fill sizes="600px" className="object-cover saturate-[0.8] contrast-[1.05]" />
          )}
        </div>
        <figcaption className="absolute bottom-[2.5%] left-[4%] font-hand text-[1.2em] text-ink/80">
          {item.id} — {item.title.toLowerCase()}
        </figcaption>
        <span aria-hidden className="absolute -top-[4%] left-[12%] h-[9%] w-[4%] rounded-full border-[3px] border-[#8f8f8f] border-b-transparent" />
      </figure>

      <div className="mt-[7%] grid grid-cols-3 gap-x-[4%]">
        <Field label="Photographer" value="[Placeholder]" />
        <Field label="Frame" value="01 / 01" />
        <Field label="Scale marker" value="Present" />
      </div>

      <p className="absolute bottom-[14%] right-[10%] rotate-[4deg] font-hand text-[1.2em] text-crimson/90" aria-label="Handwritten annotation">
        see continuation sheet
      </p>
    </Sheet>
  )
}

export function ContinuationPage({ item, total }: { item: EvidenceItem; total: number }) {
  const lines = Array.from({ length: 16 })
  return (
    <Sheet page={3} total={total}>
      <Letterhead title="Continuation Sheet" />
      <div className="mt-[4%] grid grid-cols-2 gap-x-[4%]">
        <Field label="Statement of" value="[Name withheld]" redacted />
        <Field label="Relates to" value={item.id} />
      </div>

      <div className="relative mt-[5%]">
        <div aria-hidden className="space-y-[1.2em]">
          {lines.map((_, i) => (
            <div key={i} className="h-px bg-ink/20" />
          ))}
        </div>
        <div className="absolute inset-0 space-y-[0.5em] pt-[0.1em] font-mono text-[0.72em] leading-[1.65]">
          <p>Statement text pending. Witness accounts will be transcribed onto this sheet.</p>
          <p>
            <span className="redact">Withheld section of statement — reviewing officer</span>
          </p>
          <p>Remaining lines intentionally left blank in this preview.</p>
        </div>
      </div>

      <span className="stamp absolute bottom-[18%] left-[12%] rotate-[-7deg] text-[1.1em] font-semibold text-crimson">
        Do not copy
      </span>
    </Sheet>
  )
}
