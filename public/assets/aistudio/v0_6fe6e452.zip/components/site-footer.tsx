import { CASE_ID } from '@/lib/case-data'

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-8 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground md:flex-row md:items-center md:justify-between md:px-10">
        <p>The Last Signal — {CASE_ID} — A work of fiction</p>
        <p>Design prototype. Story content pending.</p>
      </div>
    </footer>
  )
}
