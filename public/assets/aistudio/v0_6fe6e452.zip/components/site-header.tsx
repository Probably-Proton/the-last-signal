import Link from 'next/link'
import { CASE_ID } from '@/lib/case-data'

type Props = {
  current?: 'case' | 'archive' | 'viewer'
  overlay?: boolean
}

export function SiteHeader({ current, overlay = false }: Props) {
  const links = [
    { href: '/', label: 'Case file', key: 'case' },
    { href: '/archive', label: 'Evidence archive', key: 'archive' },
  ] as const

  return (
    <header
      className={
        overlay
          ? 'absolute inset-x-0 top-0 z-30'
          : 'sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur'
      }
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-4 md:px-10">
        <Link href="/" className="flex items-center gap-3">
          <span aria-hidden className="block size-2 rounded-full bg-crimson" />
          <span className="font-mono text-[11px] uppercase tracking-[0.32em] text-foreground">
            The Last Signal
          </span>
          <span className="hidden font-mono text-[11px] tracking-[0.2em] text-muted-foreground sm:inline">
            / {CASE_ID}
          </span>
        </Link>
        <nav aria-label="Primary">
          <ul className="flex items-center gap-5 md:gap-8">
            {links.map((link) => {
              const active = current === link.key || (current === 'viewer' && link.key === 'archive')
              return (
                <li key={link.key}>
                  <Link
                    href={link.href}
                    aria-current={active ? 'page' : undefined}
                    className={`font-mono text-[11px] uppercase tracking-[0.2em] transition-colors hover:text-foreground ${
                      active ? 'text-foreground underline decoration-crimson decoration-2 underline-offset-[10px]' : 'text-muted-foreground'
                    }`}
                  >
                    {link.label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>
    </header>
  )
}
