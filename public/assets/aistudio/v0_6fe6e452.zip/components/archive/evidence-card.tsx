import Image from 'next/image'
import Link from 'next/link'
import { Lock } from 'lucide-react'
import type { EvidenceItem } from '@/lib/case-data'

export function EvidenceCard({ item }: { item: EvidenceItem }) {
  const open = item.status === 'available'

  const body = (
    <>
      <div className="relative aspect-[4/3] overflow-hidden bg-card">
        {item.image ? (
          <Image
            src={item.image}
            alt={open ? item.title : ''}
            fill
            sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 100vw"
            className={`object-cover transition duration-700 ${
              open ? 'saturate-[0.75] group-hover:scale-[1.03] group-hover:saturate-100' : 'scale-110 blur-xl brightness-50 grayscale'
            }`}
          />
        ) : (
          <div className="flex h-full items-center justify-center bg-[repeating-linear-gradient(135deg,#151514_0_12px,#1a1a18_12px_24px)]">
            <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">No image on file</span>
          </div>
        )}
        <div aria-hidden className="film-grain absolute inset-0" />

        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <span className="bg-background/85 px-2 py-1 font-mono text-[10px] tracking-[0.18em] text-foreground">{item.id}</span>
          {item.classification !== 'Internal' && (
            <span className="border border-crimson/80 bg-background/70 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.22em] text-[#e0a3a3]">
              {item.classification}
            </span>
          )}
        </div>

        {!open && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center">
            <Lock aria-hidden className="size-5 text-foreground/80" />
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-foreground/90">
              {item.status === 'sealed' ? 'Sealed' : `Released at stage ${String(item.stage).padStart(2, '0')}`}
            </span>
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col border-x border-b border-border p-5">
        <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          <span>{item.kind}</span>
          <span>{item.date}</span>
        </div>
        <h3 className={`mt-3 font-serif text-2xl font-light leading-snug ${open ? 'text-foreground' : 'text-muted-foreground'}`}>
          {open ? item.title : <span className="redact">{item.title}</span>}
          {!open && <span className="sr-only">Title withheld</span>}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
        <div className="mt-auto flex items-center justify-between pt-5 font-mono text-[10px] uppercase tracking-[0.2em]">
          <span className="text-muted-foreground">Stage {String(item.stage).padStart(2, '0')}</span>
          {open && (
            <span className="text-foreground transition-colors group-hover:text-[#e0a3a3]">
              {item.hasDocument ? 'View report →' : 'View item →'}
            </span>
          )}
        </div>
      </div>
    </>
  )

  if (!open) {
    return (
      <article aria-label={`${item.id}, locked`} className="flex flex-col opacity-90">
        {body}
      </article>
    )
  }

  return (
    <article className="flex">
      <Link href={`/archive/${item.id}`} className="group flex w-full flex-col focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-crimson">
        {body}
      </Link>
    </article>
  )
}
