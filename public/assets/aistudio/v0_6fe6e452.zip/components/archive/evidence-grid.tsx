'use client'

import { useState } from 'react'
import type { EvidenceItem, EvidenceKind } from '@/lib/case-data'
import { EvidenceCard } from './evidence-card'

const filters: ('All' | EvidenceKind)[] = ['All', 'Scene photograph', 'Physical evidence', 'Location', 'Document', 'Audio']

export function EvidenceGrid({ items }: { items: EvidenceItem[] }) {
  const [filter, setFilter] = useState<(typeof filters)[number]>('All')
  const visible = filter === 'All' ? items : items.filter((item) => item.kind === filter)

  return (
    <div>
      <div className="flex flex-col gap-4 border-y border-border py-4 md:flex-row md:items-center md:justify-between">
        <div role="group" aria-label="Filter by type" className="flex flex-wrap gap-x-6 gap-y-2">
          {filters.map((f) => {
            const active = f === filter
            return (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                aria-pressed={active}
                className={`font-mono text-[11px] uppercase tracking-[0.2em] transition-colors ${
                  active ? 'text-foreground underline decoration-crimson decoration-2 underline-offset-8' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {f}
              </button>
            )
          })}
        </div>
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground" aria-live="polite">
          {String(visible.length).padStart(2, '0')} / {String(items.length).padStart(2, '0')} items
        </p>
      </div>

      <div className="mt-10 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((item) => (
          <EvidenceCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  )
}
