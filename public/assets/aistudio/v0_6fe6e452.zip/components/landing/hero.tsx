import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { CASE_ID } from '@/lib/case-data'

export function Hero() {
  return (
    <section className="relative isolate flex min-h-[100svh] flex-col justify-end overflow-hidden">
      <Image
        src="/images/hero-scene.png"
        alt="Fictional scene photograph: a rain-soaked alley at night, a handheld radio lying on wet cobblestones behind police tape."
        fill
        priority
        sizes="100vw"
        className="-z-20 object-cover object-[70%_center] saturate-[0.7]"
      />
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-r from-background via-background/75 to-background/10" />
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-t from-background via-transparent to-background/60" />
      <div aria-hidden className="rain absolute inset-0 -z-10" />
      <div aria-hidden className="film-grain absolute inset-0 -z-10" />

      <div className="mx-auto w-full max-w-7xl px-5 pb-16 pt-32 md:px-10 md:pb-24">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 font-mono text-[11px] uppercase tracking-[0.28em] text-muted-foreground">
          <span>Case no. {CASE_ID}</span>
          <span aria-hidden className="h-px w-10 bg-muted-foreground/50" />
          <span>Status: Open — unresolved</span>
        </div>

        <div className="mt-8 flex items-start gap-6">
          <h1 className="text-balance font-serif text-6xl font-light leading-[0.9] tracking-tight text-foreground sm:text-7xl md:text-8xl lg:text-[9.5rem]">
            The Last
            <br />
            <span className="italic">Signal</span>
          </h1>
          <span className="stamp mt-4 hidden -rotate-6 text-sm text-crimson md:inline-block" style={{ mixBlendMode: 'normal' }}>
            Classified
          </span>
        </div>

        <p className="mt-10 max-w-xl text-pretty text-lg leading-relaxed text-foreground/80 md:text-xl">
          A fictional investigation in seven stages. The file below has been reopened for review.
          Examine the evidence, read the reports, and follow the record where it leads.
        </p>

        <div className="mt-10 flex flex-wrap items-center gap-6">
          <Link
            href="/archive"
            className="group inline-flex items-center gap-4 bg-crimson px-7 py-4 font-mono text-xs font-medium uppercase tracking-[0.28em] text-accent-foreground transition-colors hover:bg-[#b52222] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-foreground"
          >
            Open case file
            <ArrowRight aria-hidden className="size-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <Link
            href="/archive/EV-0101"
            className="font-mono text-[11px] uppercase tracking-[0.24em] text-muted-foreground underline-offset-8 hover:text-foreground hover:underline"
          >
            Read initial report
          </Link>
        </div>
      </div>

      <dl className="relative mx-auto grid w-full max-w-7xl grid-cols-2 border-t border-border/70 px-5 font-mono text-[11px] uppercase tracking-[0.2em] md:grid-cols-4 md:px-10">
        {[
          ['Filed', '00.00.0000'],
          ['Division', '[Placeholder]'],
          ['Lead', '[Unassigned]'],
          ['Stages', '07'],
        ].map(([label, value]) => (
          <div key={label} className="border-r border-border/70 py-5 pr-4 last:border-r-0 even:pl-4 md:pl-4 md:first:pl-0">
            <dt className="text-muted-foreground">{label}</dt>
            <dd className="mt-2 text-foreground">{value}</dd>
          </div>
        ))}
      </dl>
    </section>
  )
}
