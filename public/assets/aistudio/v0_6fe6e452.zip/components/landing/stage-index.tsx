import Image from 'next/image'
import Link from 'next/link'
import { Lock } from 'lucide-react'
import { evidence, stages } from '@/lib/case-data'

export function StageIndex() {
  const featured = evidence.filter((item) => item.status === 'available' && item.image).slice(1, 4)

  return (
    <section aria-labelledby="stage-index" className="mx-auto max-w-7xl px-5 py-24 md:px-10 md:py-32">
      <div className="grid gap-16 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-crimson">Section 01</p>
          <h2 id="stage-index" className="mt-4 text-balance font-serif text-4xl font-light leading-tight md:text-5xl">
            Index of the investigation
          </h2>
          <p className="mt-6 max-w-md leading-relaxed text-muted-foreground">
            Seven stages, opened in sequence. Each stage remains sealed until it is released by the
            investigation lead. Stage contents are not shown in this preview.
          </p>

          <div className="mt-12 grid grid-cols-3 gap-3">
            {featured.map((item, i) => (
              <Link
                key={item.id}
                href={`/archive/${item.id}`}
                className={`group relative block aspect-[3/4] overflow-hidden bg-card ${i === 1 ? 'mt-8' : ''}`}
              >
                <Image
                  src={item.image!}
                  alt={item.title}
                  fill
                  sizes="(min-width: 1024px) 14vw, 30vw"
                  className="object-cover grayscale-[40%] transition duration-500 group-hover:scale-105 group-hover:grayscale-0"
                />
                <span className="absolute bottom-2 left-2 bg-background/80 px-1.5 py-0.5 font-mono text-[10px] tracking-[0.15em] text-foreground">
                  {item.id}
                </span>
              </Link>
            ))}
          </div>
        </div>

        <ol className="border-t border-border">
          {stages.map((stage) => (
            <li
              key={stage.number}
              className="grid grid-cols-[3.5rem_1fr_auto] items-baseline gap-4 border-b border-border py-6 md:grid-cols-[5rem_1fr_auto]"
            >
              <span className="font-mono text-sm text-muted-foreground">
                {String(stage.number).padStart(2, '0')}
              </span>
              <div>
                <h3 className="font-serif text-2xl font-light text-foreground md:text-3xl">{stage.title}</h3>
                <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                  {stage.subtitle}
                </p>
              </div>
              <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                <Lock aria-hidden className="size-3" />
                Sealed
              </span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
